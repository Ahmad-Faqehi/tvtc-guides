<!-- Nav Item - Messages -->
<li class="nav-item dropdown no-arrow mx-1">
    <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-envelope fa-fw"></i>
        <!-- Counter - Messages -->
        <span class="badge badge-danger badge-counter">7</span>
    </a>
    <!-- Dropdown - Messages -->
    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
        <h6 class="dropdown-header font-weight-bold text-center fonty-par bg-dark" style="font-size: medium; border-color: white">
           رسائل التواصل
        </h6>

        <a class="dropdown-item d-flex align-items-center" href="#" style="direction: rtl">
            <div class="mr-3">
                <div class="icon-circle ">
                    <i class="fas fa-envelope fa-2x "></i>
                </div>
            </div>
            <div class="text-right mr-2">
                <div class="small text-gray-500">Nov 7, 2020</div>
                <br>
                <div class="fonty-par" style="margin-top: -17px; font-size: medium">رسالة جديدة</div>
            </div>
        </a>

        <a class="dropdown-item d-flex align-items-center" href="#" style="direction: rtl">
            <div class="mr-3">
                <div class="icon-circle ">
                    <i class="fas fa-envelope fa-2x "></i>
                </div>
            </div>
            <div class="text-right mr-2">
                <div class="small text-gray-500">Nov 7, 2020</div>
                <br>
                <div class="fonty-par" style="margin-top: -17px; font-size: medium">رسالة جديدة</div>
            </div>
        </a>


        <a class="dropdown-item text-center small text-gray-500" href="#">حذف اشعارات الرسائل</a>
    </div>
</li>
