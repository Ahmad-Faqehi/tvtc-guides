<?php


class user
{
    protected static $db_table = "users";
    public $id;
    public $name;
    public $password;
    public $roal;
    public $email;


}