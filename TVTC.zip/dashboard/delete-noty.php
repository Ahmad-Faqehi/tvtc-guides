<?php
include "includes/head.php";
include "includes/Database.php";
$stm = $conn->prepare("SELECT * FROM `order` WHERE reared = 0");
$stm->execute();
$count = $stm->rowCount();
if($count > 0){
    $stmtup = $conn->prepare("UPDATE `order` SET reared = 1 WHERE reared = 0");
    $stmtup->execute();
    header("Location: index.php");
    die();
}else{
    header("Location: index.php");
}